import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from std_msgs.msg import Int64
from geometry_msgs.msg import Pose2D
import numpy as np

#Definition of node class Velocity
class Point_generator(Node):

    #Constructur method for node class
    def __init__(self):
    
    	#definition of topic
        super().__init__('Point_Generator')
        
        #Parametro del numero de puntos
        self.declare_parameter('Points',4)
        
        #variables a utilizar
        self.num_points = (self.get_parameter('Points').get_parameter_value().integer_value)
        self.x = []
        self.y = []
        self.i = 0

        #Odometria
        self.xr = 0.0
        self.yr = 0.0
        self.wr = 0.0
        
        #Timer para operaciones
        timer_period = 0.5
        self.timer = self.create_timer(timer_period, self.timer_callback)
    	
        #Print info to confirm node was made.
        self.get_logger().info('Point_generator node successfully initialized!!!')

        #Creación del tópico subcriptor: odom
        self.subscriber_2 = self.create_subscription(Pose2D, 'odom', self.odom_callback, 10)

        #create publisher for topic Point
        self.publisher = self.create_publisher(Pose2D, 'Point', 10) 

        #initialize msg data type
        self.msg = Pose2D()

    def odom_callback(self, msg):
        #Datos de pose recibidos
        self.xr = msg.x
        self.yr = msg.y
        self.wr = msg.theta

    def timer_callback(self):
        pose_msg = Pose2D()
        #calculamos los aungulos para cada uno de los puntos utilizando linspace
        angles = np.linspace(0,2*np.pi,self.num_points, endpoint=False)
        #guardamos la coordenadas de "x" y "y" en arreglos
        self.x = list(0.5 * np.cos(angles))
        self.y = list(0.5 * np.sin(angles))

        error_x = self.x[self.i] - self.xr
        error_y = self.y[self.i] - self.yr

        if (error_x <= 0.05 and error_x >= -0.05) and (error_y <= 0.05 and error_y >= -0.05):
            self.i = self.i + 1
            
        if(self.i > (self.num_points)):
            #arreglos y los guardamos en msg
            pose_msg.x = self.x[0]
            pose_msg.y = self.y[0]
            pose_msg.theta = 0.0
        else:
            #sumamos los arreglos y los guardamos en msg
            pose_msg.x = self.x[self.i]
            pose_msg.y = self.y[self.i]
            pose_msg.theta = 0.0
        #mandamos msg a Point
        self.publisher.publish(pose_msg)
        #self.get_logger().info('Punto mandado')

#Main Fnc
def main(args=None):
    #Inicialiation for rclpy 
    rclpy.init(args=args)
    #create node
    m_p = Point_generator()
    #Spin method for publisher calback
    rclpy.spin(m_p)
    #Destoy node
    m_p.destroy_node()
    #rclpy shutdown
    rclpy.shutdown()

#main call method
if __name__ == 'main':    
    main()

