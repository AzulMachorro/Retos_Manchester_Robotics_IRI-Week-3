import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from std_msgs.msg import Int64
from geometry_msgs.msg import Pose2D
from geometry_msgs.msg import Twist
import numpy as np


#Definición de la clase 
class Controller(Node):
    #Constructor 
    def __init__(self):
        
        #Definición del tópico
        super().__init__('Azul_Controller_node')
        
        #Variables para lectura de topico /odom
        self.x = 0.0
        self.y = 0.0
        self.w = 0.0
        self.c = 0

        #Punto objetivo
        self.xp = 0.0
        self.yp = 0.0
        self.wp = 0.0
        
        #Creación del tópico publicador: cmd_vel
        self.publisher = self.create_publisher(Twist, 'cmd_vel', 10)
        
        #Creación del tópico subcriptor: odom
        self.subscriber = self.create_subscription(Pose2D, 'odom', self.pose_callback, 10)
        
        #Creación del tópico subcriptor: point
        self.subscriberP = self.create_subscription(Pose2D, 'Point', self.point_callback, 10)
        
        #Definición del periodo de tiempo
        timer_period = 0.01

        #Timer para operaciones
        self.timer = self.create_timer(timer_period, self.timer_callback)

        #Confirmación de la creación del nodo
        self.get_logger().info('Controller position error node successfully initialized!!!')

        #Tipo de mensaje 
        self.msg = Float32()
        
        #Parametros de los controladores PI
        self.kp_ang = 0.1
        self.ki_ang = 0.0
        self.kp_lin = 0.4
        self.ki_lin = 0.0
        
        #Variables de error integral
        self.error_integral_ang = 0.0
        self.error_integral_lin = 0.0
     
    def pose_callback(self, msg):
        #Datos de pose recibidos
        self.x = msg.x
        self.y = msg.y
        self.w = msg.theta
        #self.get_logger().info(f'Received pose: x={msg.x}, y={msg.y}, theta={msg.theta}')
        
    def point_callback(self, msg):
        #Datos de objetivo recibidos
        self.xp = msg.x
        self.yp = msg.y

    #Método del timer
    def timer_callback(self):
        cmd_vel = Twist()
        cmd_vel.linear.y = 0.0
        cmd_vel.linear.x = 0.0
        cmd_vel.linear.z = 0.0
        cmd_vel.angular.x = 0.0
        cmd_vel.angular.y = 0.0

        lin_control_output = 0.0
        ang_control_output = 0.0

        self.wp = np.arctan2((self.yp - self.y),(self.xp - self.x))
        error_w = self.wp - self.w

        error_v = np.sqrt(((self.yp - self.y)**2) + ((self.xp - self.x)**2))

        if error_w >= 0.05 or error_w <= -0.05:
            if error_w >= np.pi:
                error_w -= 2*np.pi
            elif error_w <= -np.pi:
                error_w += 2*np.pi
            ang_control_output = self.kp_ang * error_w
            if ang_control_output < 0.1 and ang_control_output > 0.0:
                ang_control_output = 0.1
            if ang_control_output > -0.1 and ang_control_output < 0.0:
                ang_control_output = -0.1
            lin_control_output = 0.0
        else:
            if error_v >= 0.05 or error_v <= -0.5:
                lin_control_output = self.kp_lin * error_v
                if lin_control_output < 0.12 and lin_control_output > 0.0:
                    lin_control_output = 0.12
                if lin_control_output > -0.12 and lin_control_output < 0.0:
                    lin_control_output = -0.12
                ang_control_output = 0.0
            else:
                lin_control_output = 0.0
                ang_control_output = 0.0

        if ang_control_output > 0.25:
            ang_control_output = 0.25

        if ang_control_output < -0.25:
            ang_control_output = -0.25

        if lin_control_output > 0.25:
            lin_control_output = 0.25

        if lin_control_output < -0.25:
            lin_control_output = -0.25

        cmd_vel.angular.z = ang_control_output
        cmd_vel.linear.x = lin_control_output
        self.publisher.publish(cmd_vel)

        self.get_logger().info(f'V: {lin_control_output}')
        self.get_logger().info(f'W: {ang_control_output}')
        self.get_logger().info(f'error_V: {error_v}')
        self.get_logger().info(f'error_W: {error_w}')

#Main Fnc
def main(args=None):
    #Inicialiation for rclpy 
    rclpy.init(args=args)
    #create node
    m_p = Controller()
    #Spin method for publisher calback
    rclpy.spin(m_p)
    #Destoy node
    m_p.destroy_node()
    #rclpy shutdown
    rclpy.shutdown()

#main call method
if __name__ == '__main__':    
    main()
    
