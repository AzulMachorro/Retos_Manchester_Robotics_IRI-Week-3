import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
from geometry_msgs.msg import Pose2D
import numpy as np

#Definition of node class Velocity
class Odometry(Node):

    #Constructur method for node class
    def __init__(self):

        #Parametros velocidad
        self.thp = 0.0
        self.xp = 0.0
        self.yp = 0.0
        self.tp = 0.0

        #Parametros posicion
        self.th = 0.0
        self.x = 0.0
        self.y = 0.0

        #Parámetros físicos
        self.r = 0.05
        self.l = 0.19

        #Velocidades angulares de encoders 
        self.velR = 0
        self.velL = 0

        #definition of topic
        super().__init__('Azul_Odometry')

        #create subscriber for topic Azul_Velocity
        self.subR = self.create_subscription(Float32, 'VelocityEncR', self.listener_callbackR, rclpy.qos.qos_profile_sensor_data)
        self.subL = self.create_subscription(Float32, 'VelocityEncL', self.listener_callbackL, rclpy.qos.qos_profile_sensor_data)

        #Print info to confirm node was made.
        self.get_logger().info('Odometry node successfully initialized!!!')

        #Definition for timer period
        timer_period = 0.01
        self.tp = timer_period        

        #Timer para operaciones
        self.timer = self.create_timer(timer_period, self.timer_callback)

        #create publisher for topic Azul_Velocity
        self.publisher = self.create_publisher(Pose2D, 'odom', 10)

        #initialize msg data type
        self.msg = Float32()
    
    #method timer calback for node Velocity R
    def listener_callbackR(self, msg):

        #Converts encoder input to linear and angular velocity
        self.velR = msg.data

    #method timer calback for node Velocity L
    def listener_callbackL(self, msg):

        #Converts encoder input to linear and angular velocity
        self.velL = msg.data

    #method timer callback
    def timer_callback(self):

        #Fórmulas para obtener las velocidades
        self.thp = self.r * ((self.velR - self.velL)/self.l)
        self.th = self.th + (self.thp * self.tp)

        self.xp = self.r * ((self.velR + self.velL)/2) * np.cos(self.th)
        self.x = self.x + (self.xp * self.tp)

        self.yp = self.r * ((self.velR + self.velL)/2) * np.sin(self.th)
        self.y = self.y + (self.yp * self.tp)

        pose_msg = Pose2D()
        pose_msg.x = self.x * 1.1
        pose_msg.y = self.y * 1.1
        pose_msg.theta = self.th
        self.publisher.publish(pose_msg)

#Main Fnc
def main(args=None):
    #Inicialiation for rclpy 
    rclpy.init(args=args)
    #create node
    m_p = Odometry()
    #Spin method for publisher calback
    rclpy.spin(m_p)
    #Destoy node
    m_p.destroy_node()
    #rclpy shutdown
    rclpy.shutdown()

#main call method
if __name__ == 'main':    
    main()
